<footer id="footer"><!--Footer-->
    <div class="footer-bottom">
        <div class="container">
            <div class="row">
            {!! getConfigValueSettingTable('footer_information') !!}
            </div>
        </div>
    </div>
</footer><!--/Footer-->