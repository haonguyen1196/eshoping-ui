<div class="category-tab">
    <div class="col-sm-12">
        <ul class="nav nav-tabs">
            <?php $__currentLoopData = $categoryChild; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $categoryChildItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="<?php echo e($key == 0 ? 'active' : ''); ?>">
                    <a href="#category_id<?php echo e($categoryChildItem->id); ?>" data-toggle="tab"><?php echo e($categoryChildItem->name); ?></a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <div class="tab-content">
            <?php $__currentLoopData = $categoryChild; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyCategoryProduct => $categoryProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="tab-pane fade <?php echo e($keyCategoryProduct == 0 ? 'active in' : ''); ?>" id="category_id<?php echo e($categoryProduct->id); ?>" >
                    <?php $__currentLoopData = $categoryProduct->productsCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyProductItem => $productItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($keyProductItem <= 3): ?>
                            <div class="col-sm-3">
                                <div class="product-image-wrapper">
                                    <div class="single-products">
                                        <div class="productinfo text-center">
                                            <img src="<?php echo e(config('app.base_url') . $productItem->feature_image_path); ?>" alt="" />
                                            <h2><?php echo e(number_format($productItem->price)); ?> VNĐ</h2>
                                            <p><?php echo e($productItem->name); ?></p>
                                            <a href="#" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Thêm vào giỏ hàng</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div><?php /**PATH C:\xampp\htdocs\eshopper\resources\views/home/components/category_tab.blade.php ENDPATH**/ ?>