<footer id="footer"><!--Footer-->
    <div class="footer-bottom">
        <div class="container">
            <div class="row">
            <?php echo getConfigValueSettingTable('footer_information'); ?>

            </div>
        </div>
    </div>
</footer><!--/Footer--><?php /**PATH C:\xampp\htdocs\eshopper\resources\views/components/footer.blade.php ENDPATH**/ ?>